// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Call SNPs\n", stdout);
  return lionss_run_workload("snp-call");
}
