// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Poll sensor"); }
int main(){
  announce();
  return lionss_run_workload("sdi12-poll");
}
