// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pack YUV420 planes\n", stdout);
  return lionss_run_workload("yuv420pack");
}
