// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Shade graphite owl\n", stdout);
  return lionss_run_workload("graphite-owl");
}
