# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(redis_slotmove src/redis_slotmove.cpp)
set_property(TARGET redis_slotmove PROPERTY CXX_STANDARD 11)
target_link_libraries(redis_slotmove lionss pthread)

add_executable(gudgeon src/gudgeon.cpp)
set_property(TARGET gudgeon PROPERTY CXX_STANDARD 11)
target_link_libraries(gudgeon lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(sip-invite src/sip-invite.cpp)
set_property(TARGET sip-invite PROPERTY CXX_STANDARD 11)
target_link_libraries(sip-invite lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(Wayfarer src/Wayfarer.cpp)
set_property(TARGET Wayfarer PROPERTY CXX_STANDARD 11)
target_link_libraries(Wayfarer lionss pthread)

add_executable(coap-observe src/coap-observe.cpp)
set_property(TARGET coap-observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap-observe lionss pthread)

add_executable(verglas src/verglas.cpp)
set_property(TARGET verglas PROPERTY CXX_STANDARD 11)
target_link_libraries(verglas lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(gradclip-norm src/gradclip-norm.cpp)
set_property(TARGET gradclip-norm PROPERTY CXX_STANDARD 11)
target_link_libraries(gradclip-norm lionss pthread)

add_executable(WaveletDenoise src/WaveletDenoise.cpp)
set_property(TARGET WaveletDenoise PROPERTY CXX_STANDARD 11)
target_link_libraries(WaveletDenoise lionss pthread)

add_executable(kmer-count31 src/kmer-count31.cpp)
set_property(TARGET kmer-count31 PROPERTY CXX_STANDARD 11)
target_link_libraries(kmer-count31 lionss pthread)

add_executable(pacinggain src/pacinggain.cpp)
set_property(TARGET pacinggain PROPERTY CXX_STANDARD 11)
target_link_libraries(pacinggain lionss pthread)

add_executable(glint src/glint.cpp)
set_property(TARGET glint PROPERTY CXX_STANDARD 11)
target_link_libraries(glint lionss pthread)

add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(bbr-probe src/bbr-probe.cpp)
set_property(TARGET bbr-probe PROPERTY CXX_STANDARD 11)
target_link_libraries(bbr-probe lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(clayfield src/clayfield.cpp)
set_property(TARGET clayfield PROPERTY CXX_STANDARD 11)
target_link_libraries(clayfield lionss pthread)

add_executable(sdi12-poll src/sdi12-poll.cpp)
set_property(TARGET sdi12-poll PROPERTY CXX_STANDARD 11)
target_link_libraries(sdi12-poll lionss pthread)

add_executable(osm-relation-fix src/osm-relation-fix.cpp)
set_property(TARGET osm-relation-fix PROPERTY CXX_STANDARD 11)
target_link_libraries(osm-relation-fix lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(graphite-owl src/graphite-owl.cpp)
set_property(TARGET graphite-owl PROPERTY CXX_STANDARD 11)
target_link_libraries(graphite-owl lionss pthread)

add_executable(slamloopclose src/slamloopclose.cpp)
set_property(TARGET slamloopclose PROPERTY CXX_STANDARD 11)
target_link_libraries(slamloopclose lionss pthread)

add_executable(lut-grade src/lut-grade.cpp)
set_property(TARGET lut-grade PROPERTY CXX_STANDARD 11)
target_link_libraries(lut-grade lionss pthread)

add_executable(decal-atlas src/decal-atlas.cpp)
set_property(TARGET decal-atlas PROPERTY CXX_STANDARD 11)
target_link_libraries(decal-atlas lionss pthread)

add_executable(shader-hotreload src/shader-hotreload.cpp)
set_property(TARGET shader-hotreload PROPERTY CXX_STANDARD 11)
target_link_libraries(shader-hotreload lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

